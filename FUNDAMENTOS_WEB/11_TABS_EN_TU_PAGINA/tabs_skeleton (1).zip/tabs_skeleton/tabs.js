$(document).ready(function () {
  // Escribe tu código aquí
});
